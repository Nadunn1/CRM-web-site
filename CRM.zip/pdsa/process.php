<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="./mainCSS.css">
  <link rel="stylesheet" href="./mainJS.js">



  <title>process</title>
</head>

<body>

  <?php
  include "headernewnew.php";
  ?>
  <br><br>
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-12 col-lg-8 offset-lg-3 pt-5">
        <div id="columnChart"></div>

        <script>
          document.addEventListener("DOMContentLoaded", () => {
            new ApexCharts(document.querySelector("#columnChart"), {
              series: [{
                name: 'All inputs',
                data: [44, 55, 57, 56, 61, 58, 63, 60, 66]
              }, {
                name: 'Registed',
                data: [76, 85, 101, 98, 87, 105, 91, 114, 94]
              }, {
                name: 'Pending',
                data: [35, 41, 36, 26, 45, 48, 52, 53, 41]
              }],
              chart: {
                type: 'bar',
                height: 350
              },
              plotOptions: {
                bar: {
                  horizontal: false,
                  columnWidth: '55%',
                  endingShape: 'rounded'
                },
              },
              dataLabels: {
                enabled: false
              },
              stroke: {
                show: true,
                width: 2,
                colors: ['transparent']
              },
              xaxis: {
                categories: ['Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct'],
              },
              yaxis: {
                title: {
                  text: '$ (thousands)'
                }
              },
              fill: {
                opacity: 1
              },
              tooltip: {
                y: {
                  formatter: function(val) {
                    return "$ " + val + " thousands"
                  }
                }
              }
            }).render();
          });
        </script>
      </div>
    </div>
  </div>
  <div class="container-fluid">
    <div class="row">

      <div class="col-md-12 col-lg-8 offset-lg-3 pt-5">
        <h3 align="center" class="fw-bold pt-5">Today Call Jobs</h3>
        <table class="table  " id="pendingtable">
          <thead>
            <tr>
              <th class=" bg-secondary text-white">#</th>
              <th class=" bg-secondary text-white">Name</th>
              <th class=" bg-secondary text-white">city</th>
              <th class=" bg-secondary text-white">Date</th>
              <th class=" bg-secondary text-white">Phone</th>
              <th class=" bg-secondary text-white">Status</th>
              <th class=" bg-secondary text-white">Action</th>

            </tr>
          </thead>
          <tbody id="pendingtable">
            <?php

            $d = new DateTime();
            $tz = new DateTimeZone("Asia/Colombo");
            $d->setTimezone($tz);
            $today = $d->format("Y-m-d");

            $x = 1;
            $record_rs = Database::search("SELECT * FROM `customer` WHERE DATE(`follow_up_date`) = '".$today."' OR `status_id` = '1'  ORDER BY `status_id` DESC ");
            foreach ($record_rs as $record_data) {

              $status_rs = Database::search("SELECT * FROM `status` WHERE `id` = '" . $record_data["status_id"] . "' ");
              $status_data = $status_rs->fetch_assoc();
            ?>
              <tr>
                <th scope="row"><?php echo $x + 1 ?></th>
                <td> <?php echo $record_data["name"]  ?></td>
                <td><?php echo $record_data["city"]  ?></td>
                <td><?php echo $record_data["follow_up_date"]  ?></td>
                <td><?php echo $record_data["phone"]  ?></td>
                <td class=" fw-bold text-<?php echo $status_data["color"]  ?>">
                  <?php
                  echo $status_data["status"]
                  ?>
                </td>
                <td>
                  <a href="./profile.php?id=<?php echo $record_data["id"] ?>" class=" btn btn-success btn-sm">
                    <i class="bi bi-telephone-fill "></i>
                  </a>
                  <button onclick="deleteRecord('<?php echo $record_data['id'] ?>');" class=" btn btn-danger btn-sm">
                    <i class="bi bi-trash "></i>
                  </button>
                </td>
              </tr>
            <?php
              $x++;
            }
            ?>
          </tbody>
        </table>

        <div class="row">
          <div class="col-2 offset-5 pt-5">
            <button class="btn btn-secondary dropdown-toggle bg-primary" type="button" data-bs-toggle="dropdown" aria-expanded="false">
              See Other Data
            </button>
            <ul class="dropdown-menu">
              <li><a class="dropdown-item" href="./tableintrested.php">Interested</a></li>
              <li><a class="dropdown-item" href="./tablenotintrested.php">Not Interested</a></li>

              <li><a class="dropdown-item" href="./tableswillregister.php">Will Register</a></li>
              <li><a class="dropdown-item" href="./tablewillinform.php">Will Inform</a></li>
              <li><a class="dropdown-item" href="./tableregisted.php">Registerd</a></li>
              <li><a class="dropdown-item" href="./tableneverregister.php">Never Register</a></li>

            </ul>
          </div>
        </div>
      </div>
    </div>
    <br><br><br><br>

    <script src="{% static 'js/script.js' %}"></script>
    <script src="./script.js"></script>
    <script>
      new DataTable('#pendingtable');
    </script>



</body>

</html>