<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>willinform</title>
</head>
<body>
         
<?php
include "headernewnew.php";
?>

<div class="container-fluid">
        <div class="row">
           
            <div class="col-md-12 col-lg-8 offset-lg-3 pt-5">
                <h3 align="center" class="fw-bold pt-5">Will Inform</h3>
                <table class="table  " id="pendingtable">
            <thead >
              <tr >
                <th class=" bg-secondary text-white" >#</th>
                <th class=" bg-secondary text-white">Name</th>
                <th class=" bg-secondary text-white">city</th> <th class=" bg-secondary text-white">Date</th>
                <th class=" bg-secondary text-white">Phone</th>
                <th class=" bg-secondary text-white">Status</th>
                <th class=" bg-secondary text-white">Action</th>

              </tr>
            </thead>
            <tbody id="pendingtable">
              <?php

              $x = 1;
              $record_rs = Database::search("SELECT * FROM `customer` WHERE `status_id` = '2' ORDER BY `status_id` ASC ");
              foreach ($record_rs as $record_data) {

                $status_rs = Database::search("SELECT * FROM `status` WHERE `id` = '" . $record_data["status_id"] . "' ");
                $status_data = $status_rs->fetch_assoc();
              ?>
                <tr>
                  <th scope="row"><?php echo $x + 1 ?></th>
                  <td> <?php echo $record_data["name"]  ?></td>
                  <td><?php echo $record_data["city"]  ?></td><td><?php echo $record_data["follow_up_date"]  ?></td>
                  <td><?php echo $record_data["phone"]  ?></td>
                  <td class=" fw-bold text-<?php echo $status_data["color"]  ?>" >
                    <?php
                    echo $status_data["status"]
                    ?>
                  </td>
                  <td>
                    <a href="./profile.php?id=<?php echo $record_data["id"] ?>" class=" btn btn-success btn-sm">
                      <i class="bi bi-telephone-fill "></i>
                    </a>
                    <button onclick="deleteRecord('<?php echo $record_data['id'] ?>');" class=" btn btn-danger btn-sm">
                      <i class="bi bi-trash "></i>
                    </button>
                  </td>

                </tr>
              <?php
                $x++;
              }
              ?>
            </tbody>
          </table>

          <script>
            new DataTable('#pendingtable');
          </script>
          <script src="./script.js"></script>
</body>
</html>