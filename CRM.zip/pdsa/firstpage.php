<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="firstapage.css">
    <link rel="stylesheet" href="./bootstrap.css">
    <link rel="stylesheet" href="">
    
    <title>Britishway CRM System </title>
</head>
<body>



    <?php
        session_start();
        if(!isset($_SESSION["login"])){
            header("location:index.php");
        }

    ?>



    <section id="banner">
        <img src="./images/logo.jpeg" class="logo">
        <div class="banner-text">
            <h1 id="crmfont">CRM</h1>
            <p>Customer Relationship Management</p>
            <div class="banner-btn">
                <a href="./allinputs.php"><span></span> INPUT</a>
                <a href="./process.php"><span></span> PROCESS</a>
                <a href="./Report.php"><span></span> REPORT</a>
            </div>
        </div>
    
    </section>
    
    <!-- <div id="sideNav">
         
    <nav>
        <ul>
            <li><a href="#">HOME</a></li>
            <li><a href="#">FEATURES</a></li>
            <li><a href="#">SERVICE</a></li>
            <li><a href="#">TESTIMONIALS</a></li>
            <li><a href="#">MEET US</a></li>
        </ul>
    </nav>
    
    </div>
    <div id="menuBtn">
    
            <img src="./images/menuicon.png" id="menu">

            
    </div> -->
           
            
         <!-- <script>
            var menuBtn=document.getElementById("menuBtn")
            var sideNav=document.getElementById("sideNav")
            var menu=document.getElementById("menu")
    
            sideNav.style.right="-250px";
    
            menuBtn.onclick=function(){
                if(sideNav.style.right=="-250px"){
                    sideNav.style.right="0px";
                    menu.src="images/closemenu.png"
    
                }
                else {
                    sideNav.style.right="-250px";
                    menu.src="images/menuicon.png"
                }
            }
         </script> -->

    

    
    
</body>
</html>