<?php
$servername = "localhost:3306";
$username = "root";
$password = "";
$database = "britishway_crm";

?>

<?php

$user_name = $_POST["user_name"];
$user_password = $_POST["password"];

if (empty($user_name)) {
    echo "Enter User Name";
} else if (empty($user_password)) {
    echo "Enter Password";
} else {


    // Create connection
    $conn = new mysqli($servername, $username, $password, $database);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    } else {
        $sql = "SELECT * FROM useradmin WHERE user_name ='$user_name' AND password='$user_password'";
        $result = mysqli_query($conn, $sql);

        if (mysqli_num_rows($result) > 0) {
           
            echo true;
            session_start();
            $_SESSION["login"] =$user_name;

        } else {
            echo "Invalid User name or Password";
        }
    }   

    



    mysqli_close($conn);
}



?>