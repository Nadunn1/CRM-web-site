<?php

require "./dbConnection.php";

$phone = $_POST['phone'];
$gender = $_POST['gender'];
$customer_status = $_POST['customer_status'];
$course = $_POST['course'];
$status = $_POST['status'];
$intake = $_POST['intake'];
$call_date = $_POST['call_date'];
$note = $_POST['note'];
$id = $_POST['id'];
$isChanged = $_POST['isChanged'];

$d = new DateTime();
$tz = new DateTimeZone("Asia/Colombo");
$d->setTimezone($tz);
$date = $d->format("Y-m-d");

if ($status == 2 && empty($call_date)) {
    echo "Please Select next Call Date";
} elseif ($status == 3 && empty($call_date)) {
    echo "Please Select next Call Date";
} elseif ($status == 4 && empty($call_date)) {
    echo "Please Select next Call Date";
} elseif ($status == 7 && empty($call_date)) {
    echo "Please Select next Call Date";
} else {

    if ($isChanged == 1) {
        Database::iud("UPDATE `customer` SET `latest_update_date` = '" . $date . "' WHERE `id` = '" . $id . "' ");
    }

    Database::iud("UPDATE `customer` SET
    `answer_status` = '" . $phone . "',
    `gender` = '" . $gender . "',
    `customer_status` = '" . $customer_status . "',
    `course_id` = '" . $course . "',
    `status_id` = '" . $status . "',
    `intake` = '" . $intake . "',
    `note` = '" . $note . "'
    WHERE `id` = '" . $id . "';
     ");

    if (!empty($call_date)) {
        Database::iud("UPDATE `customer` SET `follow_up_date` = '" . $call_date . "' WHERE `id` = '" . $id . "' ");
    }

    echo true;
}
