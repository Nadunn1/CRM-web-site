<?php

require "./dbConnection.php";

$id = $_GET["id"];
Database::iud("DELETE FROM `customer` WHERE `id` = '".$id."' ");
echo true;

?>