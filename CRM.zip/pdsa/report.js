 function getReport(){

    var toDate = document.getElementById("to_date").value;
    var fromDate = document.getElementById("from_date").value;
    var status = document.getElementById("customer_status").value;

    if(fromDate.trim() === ''){
        alert("Please Select From Date.");
    }else if(toDate.trim() === ''){
        alert("Please Select To Date.");
    }else{

        window.open("customer_report.php?from="+fromDate+"&to="+toDate+"&status="+status);

    }

 }