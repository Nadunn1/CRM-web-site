


function inputData() {

    var name = document.getElementById("name").value;
    var mobile = document.getElementById("mobile").value;
    var email = document.getElementById("email").value;
    var city = document.getElementById("city").value;
    var address = document.getElementById("address").value;
    var method = document.getElementById("method").value;
    var intake = document.getElementById("intake").value;

    var form = new FormData();
    form.append("name", name);
    form.append("mobile", mobile);
    form.append("email", email);
    form.append("city", city);
    form.append("address", address);
    form.append("method", method);
    form.append("intake", intake);

    var xhttp = new XMLHttpRequest();
    var url = "addCustomerRecord.php";
    xhttp.onreadystatechange = function () {
        if (this.readyState == 4) {
            console.log(this.responseText)
;         if(this.responseText == true){
            alert("Data Added Successfull!");
            window.location.reload();
           }else{
            alert(this.responseText);
           }
        }
    };
    xhttp.open("POST", url, true);
    xhttp.send(form);

}