<?php
require "./dbConnection.php";

$name = $_POST["name"];
$mobile = $_POST["mobile"];
$email = $_POST["email"];
$city = $_POST["city"];
$address = $_POST["address"];
$method = $_POST["method"];
$intake = $_POST["intake"];

$check_rs = Database::search("SELECT * FROM `customer` WHERE `phone` = '" . $mobile . "' ");

if (empty($name)) {
    echo "Please enter a name\n";
} elseif ($check_rs->num_rows > 0) {
    echo "This Mobile Number alredy in the system.\n";
} elseif (empty($mobile)) {
    echo "Please enter a mobile number\n";
} elseif (empty($city)) {
    echo "Please enter a city\n";
} elseif (empty($address)) {
    echo "Please enter an address\n";
} elseif ($method == 0) {
    echo "Please enter a method\n";
} elseif ($intake == 0) {
    echo "Please enter an intake\n";
} else {
    $d = new DateTime();
    $tz = new DateTimeZone("Asia/Colombo");
    $d->setTimezone($tz);
    $date = $d->format("Y-m-d");

    Database::iud("INSERT INTO `customer` (`name`, `phone`, `email`, `city`, `address`, `intake`, `source`,  `status_id` , `latest_update_date` ) VALUES ('" . $name . "', '" . $mobile . "', '" . $email . "', '" . $city . "', '" . $address . "', '" . $intake . "', '" . $method . "' , '1' , '".$date."' ) ");


    echo true;
}
