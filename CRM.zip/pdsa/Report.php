<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./mainCSS.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <title>Report</title>
</head>

<body>


      
<?php
include "headernewnew.php";
?>


    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12 col-lg-8 offset-lg-3 pt-3">
                <h3 align="center" class="fw-bold">All Input Data Count</h3>
                <!-- Bar Chart -->
                <canvas id="barChart" style="max-height: 400px;"></canvas>
                <script>
                    document.addEventListener("DOMContentLoaded", () => {
                        new Chart(document.querySelector('#barChart'), {
                            type: 'bar',
                            data: {
                                labels: ['January', 'February', 'March', 'April', 'May', 'June', 'July'],
                                datasets: [{
                                    label: 'Bar Chart',
                                    data: [65, 59, 80, 81, 56, 55, 40],
                                    backgroundColor: [
                                        'rgba(255, 99, 132, 0.2)',
                                        'rgba(255, 159, 64, 0.2)',
                                        'rgba(255, 205, 86, 0.2)',
                                        'rgba(75, 192, 192, 0.2)',
                                        'rgba(54, 162, 235, 0.2)',
                                        'rgba(153, 102, 255, 0.2)',
                                        'rgba(201, 203, 207, 0.2)'
                                    ],
                                    borderColor: [
                                        'rgb(255, 99, 132)',
                                        'rgb(255, 159, 64)',
                                        'rgb(255, 205, 86)',
                                        'rgb(75, 192, 192)',
                                        'rgb(54, 162, 235)',
                                        'rgb(153, 102, 255)',
                                        'rgb(201, 203, 207)'
                                    ],
                                    borderWidth: 1
                                }]
                            },
                            options: {
                                scales: {
                                    y: {
                                        beginAtZero: true
                                    }
                                }
                            }
                        });
                    });
                </script>
                <!-- End Bar CHart -->
                <div class="d-grid gap-2 col-6 mx-auto pt-2">
                    <button class="btn btn-primary" type="button">View CRM Performance</button>

                </div>
                <div class="row pt-5 col-12">
                   
                    
                        



                    <!-- End Sales Card -->

                    <!-- Revenue Card -->
                    <div class="col-xxl-4 col-md-6 pt-4  col-lg-6 offset-lg-3">
                        <div class="card info-card revenue-card col" >

                            <div class="card-body ">
                                <h5 class="card-title">Customer Reports</span></h5>
                                <div class="row g-3">
                                <div class="col-12 ">
                                    <label class=" form-label">From Date:</label>
                                    <input type="date" id="from_date" class=" form-control">
                                </div>
                                <div class="col-12 ">
                                    <label class=" form-label">To Date:</label>
                                    <input type="date" id="to_date" class=" form-control">
                                </div>
                                <div class="col-12 ">
                                    <label class=" form-label">Customer Status:</label>
                                    <select class=" form-select"  id="customer_status">
                                        <option value="0">All Status</option>
                                        <?php
                                        $status_rs = Database::search("SELECT * FROM `status` ");
                                        foreach($status_rs as $status_data){
                                            ?>
                                            <option value="<?php echo $status_data["id"] ?>"><?php echo $status_data["status"] ?></option>
                                            <?php
                                        }

                                        ?>
                                    </select>
                                </div>
                                
                                <div class="col-12 d-grid">
                                    <button class=" btn btn-success" onclick="getReport();">Get Report</button>
                                </div>
                                </div>
                            </div>

                        </div>
                                  
                    </div>
                </div>
            </div>

<script src="./mainJS.js"></script>
<script src="./report.js"></script>
</body>

</html>