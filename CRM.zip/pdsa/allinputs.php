<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="./style.css">
  <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet" />
  <link rel="stylesheet" href="./navBar.css">
  <link rel="stylesheet" href="./css/bootstrap.min.css">
  <link rel="stylesheet" href="./input1.css">



  <title>Input1</title>



<body>

  <?php
  include "headernewnew.php";
  ?>
  <br><br><br>
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-12 col-lg-8 offset-lg-3 pt-5">
        <a class="btn btn-primary col-12 col-lg-4 offset-lg-8" href="./inputform1.php" role="button"><i class=" bi bi-person-add"></i> Add Customer Record</a>
        <div class="col-12">
          <table class="table  " id="pendingtable">
            <thead >
              <tr >
                <th class=" bg-secondary text-white" >#</th>
                <th class=" bg-secondary text-white">Name</th>
                <th class=" bg-secondary text-white">city</th> 
                <th class=" bg-secondary text-white">Date</th>
                <th class=" bg-secondary text-white">Phone</th>
                <th class=" bg-secondary text-white">Status</th>
                <th class=" bg-secondary text-white">Action</th>

              </tr>
            </thead>
            <tbody id="pendingtable">
              <?php

              $x = 1;
              $record_rs = Database::search("SELECT * FROM `customer` ORDER BY `status_id` ASC ");
              foreach ($record_rs as $record_data) {

                $status_rs = Database::search("SELECT * FROM `status` WHERE `id` = '" . $record_data["status_id"] . "' ");
                $status_data = $status_rs->fetch_assoc();
              ?>
                <tr>
                  <th scope="row"><?php echo $x + 1 ?></th>
                  <td> <?php echo $record_data["name"]  ?></td>
                  <td><?php echo $record_data["city"]  ?></td><td><?php echo $record_data["follow_up_date"]  ?></td>
                  <td><?php echo $record_data["phone"]  ?></td>
                  <td class=" fw-bold text-<?php echo $status_data["color"]  ?>" >
                    <?php
                    echo $status_data["status"]
                    ?>
                  </td>
                  <td>
                    <a href="./profile.php?id=<?php echo $record_data["id"] ?>" class=" btn btn-success btn-sm">
                      <i class="bi bi-telephone-fill "></i>
                    </a>
                    <button onclick="deleteRecord('<?php echo $record_data['id'] ?>');" class=" btn btn-danger btn-sm">
                      <i class="bi bi-trash "></i>
                    </button>
                  </td>

                </tr>
              <?php
                $x++;
              }


              ?>



            </tbody>
                    
          </table>
        </div>
      </div>
    </div>
  </div>



  <!-- JavaScript -->
  <script src="{% static 'js/script.js' %}"></script>
  <script>
    new DataTable('#pendingtable');
  </script>
  <script src="./script.js"></script>




</body>

</html>