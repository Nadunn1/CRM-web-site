<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer Report</title>
    <link rel="stylesheet" href="./css/bootstrap.css">
</head>

<body>

    <?php

    $to = $_GET["to"];
    $from = $_GET["from"];
    $status = $_GET["status"];

    ?>

    <div class="col-12 mt-3 col-lg-8 offset-lg-2 p-2 shadow">
        <div class="row g-2">
            <div class="col-12 text-center">
                <img src="./images/logo.jpeg" class=" img-fluid col-3" alt="">
            </div>
            <div class="col-12 fs-4 fw-bold text-center">Customer Report</div>
            <div class="col-12 ps-4 pe-4">
                <span>From Date:</span>
                <span class=" float-end"><?php echo $from ?></span>
            </div>
            <div class="col-12 ps-4 pe-4">
                <span>To Date:</span>
                <span class=" float-end"><?php echo $to ?></span>
            </div>

            <div class="col-12">
                <table class="table">
                    <thead>
                        <tr>
                            <th class=" bg-secondary text-light">Name</th>
                            <th class=" bg-secondary text-light">Mobile</th>
                            <th class=" bg-secondary text-light">Intake</th>
                            <th class=" bg-secondary text-light">Date</th>
                            <th class=" bg-secondary text-light">Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php

                        require "./dbConnection.php";

                        $sql = "SELECT * FROM `customer` WHERE `latest_update_date` >= '".$from."' AND `latest_update_date` <= '".$to."' ";
                        if ($status != 0) {
                            $sql .= "AND `status_id` = '" . $status . "' ";
                        }

                        $sql .= " ORDER BY `latest_update_date` DESC";

                        $customer_rs = Database::search($sql);
                        foreach ($customer_rs as $customer_data) {
                            $current_status_rs = Database::search("SELECT * FROM `status` WHERE `id` = '" . $customer_data["status_id"] . "' ");
                            $current_status_data = $current_status_rs->fetch_assoc();

                            $intake_rs = Database::search("SELECT * FROM `intakes` WHERE `id` = '" . $customer_data["intake"] . "' ");
                            $intake_data = $intake_rs->fetch_assoc();
                            ?>
                            <tr>
                                <td><?php echo $customer_data["name"] ?></td>
                                <td><?php echo $customer_data["phone"] ?></td>
                                <td><?php echo $intake_data["intake_name"] ?></td>
                                <td><?php echo $customer_data["latest_update_date"] ?></td>
                                <td class="text-<?php echo $current_status_data['color'] ?>"><?php echo $current_status_data["status"] ?></td>

                            </tr>
                            <?php
                        }

                        ?>

                    </tbody>
                </table>
            </div>

            
        </div>
    </div>

    <script src="./js/bootstrap.bundle.js"></script>
</body>

</html>