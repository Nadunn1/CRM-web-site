
function submit_intake_data(){

    var number = document.getElementById("number").value;
    var name = document.getElementById("name").value;
    var date = document.getElementById("date").value;

    var formData = new FormData();
  formData.append("name", name);
  formData.append("number", number);
  formData.append("date", date);
 

  var xhr = new XMLHttpRequest();
  xhr.open("POST", "addNewIntakeProcess.php", true);
  xhr.onreadystatechange = function () {
    if (xhr.readyState === 4 ) {
      if(xhr.responseText == true){
        alert("Data Added Successfull!");
        window.location.reload();
      }else{
        alert(this.responseText);
      }
    }
  };
  xhr.send(formData);

}