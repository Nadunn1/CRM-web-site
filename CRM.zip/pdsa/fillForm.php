<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="fillForm.css">
    <link rel="stylesheet" href="./bootstrap.css">
    <link rel="stylesheet" href="./css/bootstrap.min.css">
    <title>Fill form </title>
</head>

<body>




    <div class="container-fluid">
        <div class="row">
            <div id="banner" class="col-12 ">
                <div class="col-12 text-center ">
                    <img src="./images/logo.jpeg" class="logo-img">
                </div>
                <div class=" text-center text-white fw-bold col-12">
                    <h1 id="crmfont ">BRISHWAY ENGLISH ACEDEMY</h1>
                    <p>Customer Relationship Management</p>
                </div>
                <div class=" col-12 col-lg-4 offset-lg-4 ps-3 pe-3 bg-light shadow p-3 mb-5 bg-body-tertiary rounded">
                    

                <form class="row g-3">
          <div class="col-12">
            <label for="inputNanme4" class="form-label">Name</label>
            <input type="text" class="form-control" id="name">
          </div>
          <div class="col-12">
            <label for="inputEmail4" class="form-label">Phone Number</label>
            <input type="Number" class="form-control" id="mobile">
          </div>
          <div class="col-12">
            <label for="inputPassword4" class="form-label">City</label>
            <input type="text" class="form-control" id="city">
          </div>
          <div class="col-12">
            <label for="inputAddress" class="form-label">Address</label>
            <input type="text" class="form-control" id="inputAddress" placeholder="1234 Main St">
          </div>
          <select class="form-select" aria-label="Default select example">
            <option selected>How to get information</option>
            <option value="1">Phone call</option>
            <option value="2">Branch visit</option>
            <option value="3">Marcketing Campain</option>
            <option value="3">Other</option>
          </select>
          <div class="text-center">
            <button type="submit" class="btn btn-primary">Submit</button>
            <button type="reset" class="btn btn-secondary">Reset</button>
          </div>
                   
        </form>

                     




                    <p align="center">We'll never share your email with anyone else</p>
                </div>
                
            </div>
        </div>

    </div>

    






</body>

</html>