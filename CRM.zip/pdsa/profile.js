function submit_data(id) {
  var phone = document.querySelector('input[name="phone"]:checked').value;
  var gender = document.querySelector('input[name="gender"]:checked').value;
  var customer_status = document.getElementById("customer_status").value;
  var course = document.getElementById("course").value;
  var status = document.getElementById("status").value;
  var intake = document.getElementById("intake").value;
  var call_date = document.getElementById("call_date").value;
  var note = document.getElementById("note").value;

  var formData = new FormData();
  formData.append("phone", phone);
  formData.append("gender", gender);
  formData.append("customer_status", customer_status);
  formData.append("course", course);
  formData.append("status", status);
  formData.append("intake", intake);
  formData.append("call_date", call_date);
  formData.append("note", note);
  formData.append("id", id);
  formData.append("isChanged", isStatusChanged);

  var xhr = new XMLHttpRequest();
  xhr.open("POST", "addProfileData.php", true);
  xhr.onreadystatechange = function () {
    if (xhr.readyState === 4 ) {
      if(xhr.responseText == true){
        alert("Data Updated Successfull!");
        window.location.reload();
      }else{
        alert(xhr.responseText);
      };
    }
  };
  xhr.send(formData);

}

var isStatusChanged = 0;

function changeStatus(current_status){

  var status = document.getElementById("status").value;
  if(current_status != status ){
    isStatusChanged = 1;
  }else{
    isStatusChanged = 0;
  }


}
