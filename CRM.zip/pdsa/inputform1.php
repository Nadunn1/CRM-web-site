<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>inputform</title>
</head>
<body>
    
      
<?php
include "headernewnew.php";
?>

<br><br><br><br><br><br>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-12 col-lg-4 offset-lg-5 pt-3">
          <div class="col-12 pt-5">
            <label for="inputNanme4" class="form-label">Name</label>
            <input type="text" class="form-control" id="name">
          </div>
          <div class="col-12">
            <label for="inputEmail4" class="form-label">Phone Number</label>
            <input type="Number" class="form-control" id="mobile" name="phone">
          </div>
          <div class="col-12">
            <label for="inputEmail4" class="form-label">Email</label>
            <input type="text" class="form-control" id="email" name="email">
          </div>
          <div class="col-12">
            <label for="inputPassword4" class="form-label">City</label>
            <input type="text" class="form-control" id="city">
          </div>
          <div class="col-12">
            <label for="inputAddress" class="form-label">Address</label>
            <input type="text" class="form-control" id="address" >
          </div>
          <select class="form-select" aria-label="Default select example" id="method">
            <option selected value="0">How to get information</option>
            <option value="1">Phone call</option>
            <option value="2">Branch visit</option>
            <option value="3">Marcketing Campain</option>
            <option value="3">Other</option>
          </select>
          <select class="form-select" aria-label="Default select example" id="intake">
            
            <option selected value="0">Intake</option>
            <?php
            $intake_rs = Database::search("SELECT * FROM `intakes` ORDER BY id DESC ");
            foreach($intake_rs as $intake_data){
              ?>
              <option value="<?php echo $intake_data["id"] ?>"><?php echo $intake_data["intake_name"] ?></option>
              <?php
            }
            ?>
          </select>
          <div class="text-center">
            <button class="btn btn-primary" onclick="inputData()">Submit</button>
            <button type="reset" class="btn btn-secondary">Reset</button>
          </div>
                   
        </div>
    </div>
</div>
<br><br><br><br><br><br><br>
<script src="./inputform1.js"></script>
</body>
</html>