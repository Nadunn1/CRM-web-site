

<?php


class Database {

    public static $connection;

    public static function setUpConnection(){

        if(!isset(Database::$connection)){
            Database::$connection = new mysqli("localhost:3306", "root", "","britishway_crm");
            //Database::$connection = new mysqli("localhost:3306", "root", "No254@digana","mobile_hub");
             
}
    }

    public static function iud($sql){

        Database::setUpConnection();
        Database::$connection->query($sql);

    }

    public static function search($sql){

        Database::setUpConnection();
        $resalt_set = Database::$connection->query($sql);
        return $resalt_set;

    }
}

?>