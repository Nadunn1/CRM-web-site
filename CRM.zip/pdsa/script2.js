
function login() {
    var user_name = document.getElementById("yourUsername").value;
    var password = document.getElementById("yourPassword").value;
    //    alert(user_name)
    //    alert(password)


    var loginadmin = new FormData();
    loginadmin.append("user_name", user_name)
    loginadmin.append("password", password)

    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function () {
        if (this.readyState == 4) {
            // methana gahanna oni backend eken ena respons eka anuwa karanna oni de
            if (xhttp.responseText == true) {
                window.location = "firstpage.php";
            } else {
                alert(xhttp.responseText);
            }
        }
    };
    xhttp.open("POST", "loginprocess.php", true);
    xhttp.send(loginadmin);
};

function input_form() {

    var password = document.getElementById("inputNanme4").value;
    var password = document.getElementById("inputphone").value;
    var password = document.getElementById("inputemail").value;
    var password = document.getElementById("inputcity").value;
    var password = document.getElementById("inputaddress").value;


    var loginadmin = new FormData();

    loginadmin.append("inputNanme4", inputNanme4)
    loginadmin.append("inputphone", inputphone)
    loginadmin.append("inputemail", inputemail)
    loginadmin.append("inputcity", inputcity)
    loginadmin.append("inputcity", inputcity)

    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function () {
        if (this.readyState == 4) {
            // methana gahanna oni backend eken ena respons eka anuwa karanna oni de
            if (xhttp.responseText == true) {
                window.location = "firstpage.php";
            } else {
                alert(xhttp.responseText);
            }
        }
    };
    xhttp.open("POST", "loginprocess.php", true);
    xhttp.send(loginadmin);

}