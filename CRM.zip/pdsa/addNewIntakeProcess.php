<?php

require "./dbConnection.php";

$number = $_POST["number"];
$name = $_POST["name"];
$date = $_POST["date"];

if(empty($number)){
    echo "Please enter intake number";
}else if(empty($name)){
    echo "Please enter intake name";
}else if(empty($date)){
    echo "Please enter intake date";
}else{

    Database::iud("INSERT INTO `intakes` (`intake_name`, `date`, `remark`) VALUES ('".$name."' , '".$date."' , '".$number."') ");
    echo true;

}

?>