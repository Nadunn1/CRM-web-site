<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="./mainCSS.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">

  <title>profile</title>
</head>

<body>




  <div class="container-fluid">
    <div class="row">

      <?php
      include "headernewnew.php";

      $customer_rs = Database::search("SELECT * FROM `customer` WHERE `id` = '" . $_GET["id"] . "' ");
      $customer_data = $customer_rs->fetch_assoc();

      $current_status_rs = Database::search("SELECT * FROM `status` WHERE `id` = '" . $customer_data["status_id"] . "' ");
      $current_status_data = $current_status_rs->fetch_assoc();

      $intake_rs = Database::search("SELECT * FROM `intakes` WHERE `id` = '" . $customer_data["intake"] . "' ");
      $intake_data = $intake_rs->fetch_assoc();

      $information_status_rs = Database::search("SELECT * FROM `information_status` WHERE `id` = '" . $customer_data["source"] . "' ");
      $information_status_data = $information_status_rs->fetch_assoc();

      ?>
      <div class="col-md-12 col-lg-8 offset-lg-3 bg-light shadow p-3 mb-5 bg-body-tertiary rounded  ">

        <section class="section profile mt-5">
          <div class="row">
            <div class="col-xl-4 bg-light shadow p-3 mb-5 bg-body-tertiary rounded ">

              <div class="card">
                <div class="card-body profile-card pt-2 d-flex flex-column align-items-center ">
                  <h2><?php echo $customer_data["name"] ?></h2>
                  <h3><?php echo $customer_data["phone"] ?></h3>

                </div>
              </div>

            </div>

            <div class="col-xl-8">

              <div class="card">
                <div class="card-body pt-3">
                  <!-- Bordered Tabs -->
                  <ul class="nav nav-tabs nav-tabs-bordered">




                    <div class="tab-content col-12 pt-2">

                      <div class="tab-pane fade show active profile-overview" id="profile-overview">

                        <h5 class="card-title">Profile Details</h5>

                        <div class="row">
                          <div class="col-lg-5 col-md-4 label ">Full Name</div>
                          <div class="col-lg-7 col-md-8"><?php echo $customer_data["name"] ?></div>
                        </div>


                        <div class="row">
                          <div class="col-lg-5 col-md-4 label">Phone</div>
                          <div class="col-lg-7 col-md-8"><?php echo $customer_data["phone"] ?></div>
                        </div>

                        <div class="row">
                          <div class="col-lg-5 col-md-4 label">Address</div>
                          <div class="col-lg-7 col-md-8"><?php echo $customer_data["address"] ?></div>
                        </div>



                        <div class="row">
                          <div class="col-lg-5 col-md-4 label">Information Status</div>
                          <div class="col-lg-7 col-md-8"><?php echo $information_status_data["status"] ?></div>
                        </div>

                        <div class="row">
                          <div class="col-lg-5 col-md-4 label">Intake Name</div>
                          <div class="col-lg-7 col-md-8"><?php echo $intake_data["intake_name"] ?> ( <?php echo $intake_data["remark"] ?> ) </div>
                        </div>

                      </div>

                      <div class="tab-pane fade profile-edit pt-3" id="profile-edit">
                      </div>
                    </div>

                </div>
              </div>

            </div>
          </div>
        </section>
        
        <!-- formm -->

        <div class="col-12 bg-light shadow p-3 mb-5 bg-body-tertiary rounded">
            <fieldset class="row mb-3">
              <legend class="col-form-label col-sm-2 pt-0">Phone</legend>
              <div class="col-sm-10">

                <div class="form-check">
                  <input class="form-check-input" checked type="radio" name="phone" id="phone_answer" value="1">
                  <label class="form-check-label" for="phone_answer">
                    Answer
                  </label>
                </div>
                <div class="form-check disabled">
                  <input class="form-check-input" type="radio" name="phone" id="phone_not_answer" value="0">
                  <label class="form-check-label" for="phone_not_answer">
                    Not Answer
                  </label>
                </div>
              </div>
            </fieldset>

            <fieldset class="row mb-3">
              <legend class="col-form-label col-sm-2 pt-0">Gender</legend>
              <div class="col-sm-10">

                <div class="form-check">
                  <input class="form-check-input" checked type="radio" name="gender" id="male" value="1">
                  <label class="form-check-label" for="male">
                    Male
                  </label>
                </div>
                <div class="form-check disabled">
                  <input class="form-check-input" type="radio" name="gender" id="female" value="2">
                  <label class="form-check-label" for="female">
                    Female
                  </label>
                </div>
              </div>
            </fieldset>

            <div class="row mb-3">
              <label class="col-sm-2 col-form-label">Customer Status</label>
              <div class="col-sm-10">
                <select class="form-select" aria-label="Default select example" id="customer_status">
                  <option value="1">Student</option>
                  <option value="2">Employeed</option>
                </select>
              </div>
            </div>

            <div class="row mb-3">
              <label class="col-sm-2 col-form-label">Interested Course</label>
              <div class="col-sm-10">
                <select class="form-select" aria-label="Default select example" id="course">
                <?php
                  $course_rs = Database::search("SELECT * FROM `course` ORDER BY id DESC ");
                  foreach ($course_rs as $course_data) {
                  ?>
                    <option
                    <?php
                    if($customer_data["course_id"] != null){
                      if($customer_data["course_id"] == $course_data["id"] ){
                        echo "selected";
                      }
                    }
                    
                    ?>
                    value="<?php echo $course_data["id"] ?>"><?php echo $course_data["name"] ?></option>
                  <?php
                  }
                  ?>
                </select>
              </div>
            </div>

            <div class="row mb-3">
              <label class="col-sm-2 col-form-label">Registration Status</label>
              <div class="col-sm-10">
                <select class="form-select" onchange="changeStatus('<?php echo $customer_data['status_id'] ?>')" aria-label="Default select example" id="status">
                  <?php
                  $status_rs = Database::search("SELECT * FROM `status` ORDER BY id DESC ");
                  foreach ($status_rs as $status_data) {
                  ?>
                    <option
                    <?php
                    if($customer_data["status_id"] == $status_data["id"] ){
                      echo "selected";
                    }
                    ?>
                    value="<?php echo $status_data["id"] ?>"><?php echo $status_data["status"] ?></option>
                  <?php
                  }
                  ?>
                </select>
              </div>
            </div>
            <div class="row mb-3">
              <label class="col-sm-2 col-form-label">Intake</label>
              <div class="col-sm-10">
                <select class="form-select" aria-label="Default select example" id="intake">
¥                  <?php
                  $intake_rs = Database::search("SELECT * FROM `intakes` ORDER BY id DESC ");
                  foreach ($intake_rs as $intake_data) {
                  ?>
                    <option
                    <?php
                    if($customer_data["intake"] == $intake_data["id"] ){
                      echo "selected";
                    }
                    ?>
                    value="<?php echo $intake_data["id"] ?>"><?php echo $intake_data["intake_name"] ?></option>
                  <?php
                  }
                  ?>

                </select>
              </div>
            </div>

            <!-- date -->

            <div class="row mb-3">
              <label for="inputPassword" class="col-sm-2 col-form-label">Next Call Date</label>
              <div class="col-sm-10">
                <input type="date" value="<?php echo $customer_data["follow_up_date"] ?>" class=" form-control" id="call_date">
              </div>
            </div>

            <div class="row mb-3">
              <label for="inputPassword" class="col-sm-2 col-form-label">NOTE</label>
              <div class="col-sm-10">
                <textarea class="form-control" style="height: 100px" id="note"><?php echo $customer_data["note"] ?></textarea>
              </div>
            </div>
            <div class="row mb-3">
              <label class="col-sm-2 col-form-label"></label>
              <div class="col-sm-10">
                <button  class="btn btn-primary" onclick="submit_data('<?php echo $_GET['id'] ?>')" >Submit Form</button>
              </div>
            </div>

        </div>



      </div>
    </div>
  </div>





<script src="./profile.js"></script>

</body>

</html>