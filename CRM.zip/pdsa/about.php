<!DOCTYPE html>
<html lang="en">

<head>
   
    <title>about</title>

<body>
       
<?php
include "headernewnew.php";
?>



    <div class="container">
        <div class="row">
           
            <div class="col-12 col-lg-9 offset-lg-3">
                <div
                    class="p-3 mb-2 bg-secondary-subtle text-primary-emphasis test shadow-lg p-3 mb-5 bg-body-tertiary rounded">
                    <div id="carouselExampleIndicators" class="carousel slide">
                        <div class="carousel-indicators">
                            <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0"
                                class="active" aria-current="true" aria-label="Slide 1"></button>
                            <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1"
                                aria-label="Slide 2"></button>
                            <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2"
                                aria-label="Slide 3"></button>
                        </div>
                        <div class="carousel-inner">
                            <div class="carousel-item active">
                                <img src="./images/mainphoto.jpg" class="d-block w-100" alt="...">
                            </div>
                            <div class="carousel-item">
                                <img src="./images/logo.jpeg" class="d-block w-100" alt="...">
                            </div>
                            <div class="carousel-item">
                                <img src="..." class="d-block w-100" alt="...">
                            </div>
                        </div>
                        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators"
                            data-bs-slide="prev">
                            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                            <span class="visually-hidden">Previous</span>
                        </button>
                        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators"
                            data-bs-slide="next">
                            <span class="carousel-control-next-icon" aria-hidden="true"></span>
                            <span class="visually-hidden">Next</span>
                        </button>
                    </div>
                    <div class="col-12 parahraph">
                        <p class="text-capitalize">A Customer Relationship Management (CRM) system is a software tool
                            designed to help businesses manage interactions and relationships with current and potential
                            customers. It serves as a centralized hub for organizing customer data, communication
                            history, sales activities, and marketing efforts. Here's a detailed description:</p>

                        <div class="row">
                            <div class="col-12 col-lg-4 col-md-6 pt-100">
                                <div class="card" style="width: 18rem;">
                                    <img src="./images/card1.jpg" class="card-img-top" alt="...">
                                    <div class="card-body">
                                        <p class="card-text">
                                        <p class="fw-bold">Centralized Customer Data Management</p>
                                        CRM systems gather and store all customer-related information in one place. This
                                        includes contact details, communication history, purchase history, preferences,
                                        and
                                        any other relevant data. Having this information readily accessible allows
                                        businesses to understand their customers better and tailor their interactions
                                        accordingly.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-12 col-lg-4 col-md-6">
                                <div class="card" style="width: 18rem;">
                                    <img src="./images/card2.jpg" class="card-img-top" alt="...">
                                    <div class="card-body">
                                        <p class="card-text">
                                        <p class="fw-bold">Improved Customer Communication</p>
                                        CRM systems facilitate better communication with customers through various
                                        channels such as email, phone calls, social media, and live chat. They often
                                        include features like email templates, automated responses, and scheduling tools
                                        to streamline communication processes and ensure timely responses to customer
                                        inquiries.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-12 col-lg-4 col-md-6">
                                <div class="card" style="width: 18rem;">
                                    <img src="./images/card3.jpg" class="card-img-top" alt="...">
                                    <div class="card-body">
                                        <p class="card-text">
                                        <p class="fw-bold">Marketing Automation</p>
                                        Many CRM systems offer marketing automation capabilities, allowing businesses to
                                        create targeted marketing campaigns, segment their customer base, and track the
                                        effectiveness of their marketing efforts. This includes features like lead
                                        scoring, email marketing, and campaign analytics. 

                                    
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>



    <!-- JavaScript -->
    <script src="{% static 'js/script.js' %}"></script>
    <script src="./script.js"></script>




</body>

</html>